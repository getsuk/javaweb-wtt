package com.atguigu.headline.dao;

import com.atguigu.headline.pojo.NewsUser;

public interface NewsUserDao {
    /**
     *
     * @param username
     * @return
     */
    NewsUser findByUsernmame(String username);

    /**
     *
     * @param userId
     * @return
     */
    NewsUser findByUid(Integer userId);

    /**
     *
     * @param registerUser
     * @return
     */
    Integer insertUser(NewsUser registerUser);
}
