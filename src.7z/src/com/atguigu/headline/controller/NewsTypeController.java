package com.atguigu.headline.controller;

import jakarta.servlet.annotation.WebServlet;

@WebServlet("/type/*")
public class NewsTypeController extends BaseController {

}
