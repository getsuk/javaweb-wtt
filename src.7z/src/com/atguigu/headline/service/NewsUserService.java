package com.atguigu.headline.service;

import com.atguigu.headline.pojo.NewsUser;

public interface NewsUserService {
    /**
     *
     * @param username
     * @return
     */
    NewsUser findByUsername(String username);

    /**
     * 根据提供的uid找到用户的方法
     * @param userId
     * @return
     */
    NewsUser findByUid(Integer userId);

    /**
     *
     * @param registerUser
     * @return
     */
    Integer registUser(NewsUser registerUser);
}
